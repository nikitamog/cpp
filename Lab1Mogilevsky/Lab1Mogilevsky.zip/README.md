* Lab #1 Assignments
** Part I
*** Stack-Based ptr implementation
 Lab1-1Mogilevsky.cpp
*** Stack-Based Array and max val
Lab1-2Mogilevsky.cpp
** Part II
*** Heap-Based ptr implementation
Lab1-3Mogilevsky.cpp
*** Heap-Based Array and max val
Lab1-4Mogilevsky.cpp
** Part III
*** Ptr program and main class
Lab1-5Mogilevsky.cpp
